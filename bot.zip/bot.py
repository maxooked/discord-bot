import discord
from discord.ext import commands
import sqlite3

intents = discord.Intents.default()
intents.members = True
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)

# ================= DATABASE =================
db = sqlite3.connect("bot.db", check_same_thread=False)
cursor = db.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY,
    xp INTEGER
)
""")

db.commit()

# ================= READY =================
@bot.event
async def on_ready():
    try:
        synced = await bot.tree.sync()
        print(f"✅ Slash synced: {len(synced)}")
    except Exception as e:
        print(e)

    print(f"🤖 {bot.user} is online!")

# ================= XP SYSTEM =================
@bot.event
async def on_message(message):
    if message.author.bot:
        return

    cursor.execute("SELECT xp FROM users WHERE user_id=?", (message.author.id,))
    data = cursor.fetchone()

    if data:
        xp = data[0] + 5
        cursor.execute("UPDATE users SET xp=? WHERE user_id=?", (xp, message.author.id))
    else:
        xp = 5
        cursor.execute("INSERT INTO users VALUES (?, ?)", (message.author.id, xp))

    db.commit()
    await bot.process_commands(message)

# ================= EMBED =================
def make_embed(title, desc):
    return discord.Embed(title=title, description=desc, color=discord.Color.blue())

# ================= PING =================
@bot.command()
async def ping(ctx):
    await ctx.send("🏓 Pong!")

@bot.tree.command(name="ping", description="Test bot")
async def ping_slash(interaction: discord.Interaction):
    await interaction.response.send_message("🏓 Pong!")

# ================= EMBED =================
@bot.command()
async def embed(ctx, *, text):
    try:
        title, desc = text.split("|")
    except:
        return await ctx.send("Gebruik: !embed titel | beschrijving")

    await ctx.send(embed=make_embed(title, desc))

@bot.tree.command(name="embed", description="Maak embed")
async def embed_slash(interaction: discord.Interaction, title: str, description: str):
    await interaction.response.send_message(embed=make_embed(title, description))

# ================= CLEAR =================
@bot.command()
@commands.has_permissions(manage_messages=True)
async def clear(ctx, amount: int):
    await ctx.channel.purge(limit=amount + 1)
    await ctx.send(f"🧹 {amount} verwijderd", delete_after=3)

@bot.tree.command(name="clear", description="Delete messages")
async def clear_slash(interaction: discord.Interaction, amount: int):
    if not interaction.user.guild_permissions.manage_messages:
        return await interaction.response.send_message("❌ Geen permissie", ephemeral=True)

    await interaction.channel.purge(limit=amount + 1)
    await interaction.response.send_message("🧹 Geschoond", ephemeral=True)

# ================= KICK =================
@bot.command()
@commands.has_permissions(kick_members=True)
async def kick(ctx, member: discord.Member, *, reason="Geen reden"):
    await member.kick(reason=reason)
    await ctx.send(f"👢 {member} gekickt")

@bot.tree.command(name="kick", description="Kick user")
async def kick_slash(interaction: discord.Interaction, user: discord.Member, reason: str = "Geen reden"):
    if not interaction.user.guild_permissions.kick_members:
        return await interaction.response.send_message("❌ Geen permissie", ephemeral=True)

    await user.kick(reason=reason)
    await interaction.response.send_message(f"👢 {user} gekickt")

# ================= RANK =================
@bot.command()
async def rank(ctx):
    cursor.execute("SELECT xp FROM users WHERE user_id=?", (ctx.author.id,))
    data = cursor.fetchone()

    xp = data[0] if data else 0

    await ctx.send(embed=make_embed("📊 Rank", f"{ctx.author.mention} → {xp} XP"))

@bot.tree.command(name="rank", description="XP check")
async def rank_slash(interaction: discord.Interaction):
    cursor.execute("SELECT xp FROM users WHERE user_id=?", (interaction.user.id,))
    data = cursor.fetchone()

    xp = data[0] if data else 0

    await interaction.response.send_message(embed=make_embed("📊 Rank", f"{interaction.user.mention} → {xp} XP"))

# ================= TOP =================
@bot.command()
async def top(ctx):
    cursor.execute("SELECT user_id, xp FROM users ORDER BY xp DESC LIMIT 5")
    rows = cursor.fetchall()

    text = ""
    for i, r in enumerate(rows, start=1):
        user = await bot.fetch_user(r[0])
        text += f"{i}. {user.name} - {r[1]} XP\n"

    await ctx.send(embed=make_embed("🏆 Leaderboard", text))

@bot.tree.command(name="top", description="Leaderboard")
async def top_slash(interaction: discord.Interaction):
    cursor.execute("SELECT user_id, xp FROM users ORDER BY xp DESC LIMIT 5")
    rows = cursor.fetchall()

    text = ""
    for i, r in enumerate(rows, start=1):
        user = await bot.fetch_user(r[0])
        text += f"{i}. {user.name} - {r[1]} XP\n"

    await interaction.response.send_message(embed=make_embed("🏆 Leaderboard", text))

# ================= USER INFO =================
@bot.command()
async def userinfo(ctx, member: discord.Member = None):
    member = member or ctx.author

    e = discord.Embed(title="👤 User Info")
    e.add_field(name="Naam", value=member.name)
    e.add_field(name="ID", value=member.id)

    await ctx.send(embed=e)

# ================= START =================
bot.run("MTQ5OTQ5Nzc2MDU2MTQzMDYwOQ.GPUcS1.zu5580VRnP6CH4qYJrqo-3ylYRNBrbwbRp-aRM")